import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Main{
  static int numCnt;
  static int[] nums = new int[31];
  static boolean[] isPrime = new boolean[100001];
  static double startClock;
  static double endClock;



  public static int GCD(int a, int b) {
    if (a < b) {
      int tmp = a;
      a = b;
      b = tmp;
    }
    while (true) {
      int r = a % b;
      if (r == 0)
        return b;
      a = b;
      b = r;
    }
  }




  public static void eratos() {
    for (int i = 2; i <= 100000; i++) {
      isPrime[i] = true;
    }
    for (int i = 2; i * i <= 100000; i++) {
      if (isPrime[i]) {
        for (int j = i * i; j <= 100000; j += i) {
          isPrime[j] = false;
        }
      }
    }
  }

  public static void main(String[] args) throws Exception {
    BufferedReader br = 
      new BufferedReader(new InputStreamReader(System.in));
    StringTokenizer st;

    System.out.println("Input the number of numbers to process: ");
    while(true){
      try{
        st = new StringTokenizer(br.readLine());
        numCnt = Integer.parseInt(st.nextToken());
        if(st.hasMoreTokens() || !( 2<=numCnt && numCnt <=30)){
          throw new Exception();
        }
      } catch (Exception e) {
        System.out.print("Invalid input.  Try again: ");
        continue;
      }
      break;
    }

    System.out.println("Input the numbers to be processed:");
    while(true){
      try{
        st = new StringTokenizer(br.readLine());
        int i = 1;
        while(i <= numCnt){
          nums[i] = Integer.parseInt(st.nextToken());
          i++;
        }
        if(st.hasMoreTokens() && !(1<= nums[i] && nums[i] <= 100000)){
          throw new Exception();
        }
      } catch (Exception e){
          System.out.println("Invalid input.  Try again: ");
          continue;
      }
        break;
    }





    startClock = System.currentTimeMillis();

    int gcd = GCD(nums[1], nums[2]);
    for (int i = 3; i <= numCnt; i++) {
      gcd = GCD(nums[i], gcd);
    }
    System.out.print("GCD of input numbers is "+gcd);

    for (int i = 1; i < numCnt; i++) { // selection sort
      int minIdx = i;
      int tmp = nums[i];
      for (int j = i + 1; j <= numCnt; j++) {
        if (nums[minIdx] > nums[j]) {
          minIdx = j;
        }
      }
      nums[i] = nums[minIdx];
      nums[minIdx] = tmp;
    }

    eratos();
    for (int i = 1; i < numCnt; i++) {
      int cnt = 0;
      if (nums[i] == nums[i + 1]) {
        continue;
      }
      for (int j = nums[i]; j <= nums[i + 1]; j++) {
        if (isPrime[j]) {
          cnt++;
        }
      }
      System.out.println("Number of prime numbers between " + nums[i] +", "+nums[i+1]+": "+cnt);
    }
    endClock = System.currentTimeMillis();
    double duration = (endClock-startClock)/10000;
    System.out.printf("Total execution time using Java is %.10f seconds!", duration);
    
  }
}
